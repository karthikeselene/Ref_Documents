UPDATE syndicatePartnerData SET automaticDebit = 1, balanceGracePeriod = 200 WHERE id = 1;
UPDATE syndicatePartnerData SET automaticDebit = 1, balanceGracePeriod = 300 WHERE id = 62;
UPDATE syndicatePartnerData SET bank_id = 21 WHERE id in (1,62);

UPDATE contractFunding SET releasedDatestamp = CURRENT_TIMESTAMP + 1 WHERE id = 369831;

SELECT 
sp.id,
sp.contact_id,
sp.automaticDebit,
sp.balanceGracePeriod,
sp.accountNumber, 
sp.participationType_id, 
sp.balanceGracePeriod as amount, 
sp.transferMethod_id, 
ct.contactFirstName, 
ct.contactName, 
ct.legalName, 
bn.id AS bank_id, 
bn.name AS bank_name, 
bn.routingNumber, 
bn.active, 
bn.is_ACH 
	FROM [dbo].[syndicatePartnerData] AS [sp] 
	INNER JOIN [dbo].[contacts] [ct] ON [ct].[id] = [sp].[contact_id] 
	LEFT JOIN [dbo].[banks] [bn] ON [sp].[bank_id] = [bn].[id] 
	INNER JOIN [dbo].[contractSyndicate] [cs] ON [cs].[contact_id] = [sp].[contact_id] 
	INNER JOIN [dbo].[contractFunding] [cf] ON [cf].[contract_id] = [cs].[contract_id] 
		WHERE ([sp].[balanceGracePeriod] > 0 
			AND [sp].[participationType_id] > 1
			AND [sp].[automaticDebit] = 1 
			AND DATEDIFF(day, cast(cf.releaseddatestamp as date) , getdate() )  < 1)