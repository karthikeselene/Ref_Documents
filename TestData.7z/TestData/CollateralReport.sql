SELECT 
[ctr].[StartDate] AS [Contract Funding Date], 
[ctr].[StartCollectingOn], 
[ctr].[EndDate],[ctr].[id] AS [Contract Id], 
[m].[id] AS [Merchant Id], 
[m].[MerchantDBA] AS [Merchant DBA],
[ms].[MerchantStatus] AS [Merchant Status], 
[ctr].[FundingAmount] AS [Funding Amount],
[ctr].[Rate] AS [Factor Rate],(SELECT SUM([rtr]) 
    FROM [dbo].[contractInstallmentDepositTypes] 
    WHERE [released_datestamp] <= CURRENT_TIMESTAMP
        AND [contract_id] = [ctr].[id]) AS [Released RTR],DATEDIFF(day,
    COALESCE(
        (
        SELECT TOP 1 [cph2].[date_applied] AS [date]
            fROM [contractPaymentHistory] AS [cph2]
            WHERE [cph2].contract_id = [ctr].id
                AND CAST([cph2].[date_applied] AS DATE) <= CURRENT_TIMESTAMP
                AND [cph2].[installment_id] = 0
                AND [cph2].[depositType_id] = 0
                AND [cph2].[amount] > 0
                AND [cph2].[flagPaymentType] <> 7
            ORDER BY [cph2].[date_applied] DESC
        ),
        COALESCE([ctr].StartCollectingOn,[ctr].StartDate)
    ),
	CURRENT_TIMESTAMP
	) AS [Days Since Last Activity],[ctr].[turn] AS [Turn (Months)],(SELECT SUM([amount]) 
    FROM [dbo].[contractPaymentHistory] 
    WHERE [flagPaymentType] <> 7 
        AND [date_applied] <= CURRENT_TIMESTAMP
        AND [installment_id] = 0 
        AND [depositType_id] = 0 
        AND [contractPaymentHistory].[contract_id] = [ctr].[id]) 
    AS [totalContractPayments],(SELECT SUM([amount]) 
    FROM [dbo].[contractPaymentHistory] 
    WHERE cast([date_applied] as date) = convert(varchar(10),getdate(),101)
        AND [contractPaymentHistory].[date_cleared] IS NOT NULL 
        AND [contractPaymentHistory].[contract_id] = [ctr].[id] 
        AND [installment_id] = 0 
        AND [depositType_id] = 0) 
    AS [Total Remit on 12/27/2019],(SELECT TOP 1 [participationPercentage] 
    FROM [dbo].[contractSyndicate] AS [cs] 
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3873) AS [Kapitus Participation],(SELECT TOP 1 [participationPercentage] 
    FROM [dbo].[contractSyndicate] AS [cs] 
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3002662) AS [SFS Securitization Participation],(SELECT TOP 1 [participationPercentage] 
    FROM [dbo].[contractSyndicate] AS [cs] 
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3214232) AS [SFS Warehouse Tranche 1 Participation],(SELECT TOP 1 [participationPercentage] 
    FROM [dbo].[contractSyndicate] AS [cs] 
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 21001) AS [Kapitus Write-off Participation],(SELECT TOP 1 [participationPercentage] 
    FROM [dbo].[contractSyndicate] AS [cs] 
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3214212) AS [SFS Securitization Writeoff Participation],(SELECT TOP 1 [participationPercentage] 
    FROM [dbo].[contractSyndicate] AS [cs] 
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3214252) AS [SFS Warehouse Tranche 1 Writeoff Participation],(SELECT TOP 1 [participationPercentage] 
    FROM [dbo].[contractSyndicate] AS [cs] 
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 454011) AS [SFS New Bankcard Participation],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3873) AS [Kapitus RTR],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 21001) AS [Kapitus Write-off RTR],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3214212) AS [SFS Securitization Write-off RTR],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3214252) AS [SFS Warehouse Tranche 1 Writeoff RTR],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 454011) AS [SFS New Bankcard RTR],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3002662) AS [SFS Securitization RTR],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3214232) AS [SFS Warehouse Tranche 1 RTR],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 438401) AS [rtrBCF],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 454011) AS [rtrNewBCF],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 457641) AS [rtrNationwide],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 791641) AS [rtrNewEra],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 907481) AS [rtrSFSCheck],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3002662) AS [rtrSFSSecuritization],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3214232) AS [rtrSFSWarehouse],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3143342) AS [rtrShiftCo],(SELECT TOP 1 [participationPercentage] 
    FROM [dbo].[contractSyndicate] AS [cs] 
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3817572) AS [SFS Warehouse Tranche 2 Participation],(SELECT TOP 1 [participationPercentage] 
    FROM [dbo].[contractSyndicate] AS [cs] 
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3819342) AS [SFS Warehouse Tranche 2 Writeoff Participation],(SELECT [currentRTRCleared] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3817572) AS [SFS Warehouse Tranche 2 RTR],(SELECT [originalRTR] 
    FROM [dbo].[contractSyndicate] AS [cs]
    WHERE [cs].[contract_id] = [ctr].[id] 
        AND [cs].[contact_id] = 3819342) AS [SFS Warehouse Tranche 2 Writeoff RTR],[ma].[city] AS [City], [s].[stateCode] AS [State] FROM [dbo].[merchants] AS [m] INNER JOIN [dbo].[contracts] [ctr] ON [m].[id] = [ctr].[merchant_id]
            AND [ctr].[contractStatus_id] = 12 LEFT OUTER JOIN [dbo].[merchantStatus] [ms] ON [ms].[id] = [m].[merchantStatus_id] LEFT OUTER JOIN [dbo].[merchantAddresses] [ma] ON [m].[id] = [ma].[merchant_id] AND [ma].[addressType_id]
            IN (1,6) LEFT OUTER JOIN [dbo].[state] [s] ON [s].[id] = [ma].[state_id] WHERE [m].[merchantStatus_id] IN ( 2, 3, 4, 5, 6, 7, 10, 12)
            AND [ctr].[StartDate] <= CURRENT_TIMESTAMP
            AND ([ctr].[endDate] >= CURRENT_TIMESTAMP OR [ctr].[endDate] IS NULL) ORDER BY [m].[MerchantDBA] ASC