SELECT 
[cf].[amount] AS [PAYAMT],
[b].[routingNumber] AS [RCVBNKID],
[moa].[accountNumber] AS [RCVPRTYACCT],
[moa].[legalName] AS [legalName],
[m].[MerchantName] AS [MerchantName],
[b].[name] AS [RCVBNKNM],
[b].[address] AS [RCVBNKADDR1],
[b].[city] AS [RCVBNKCTY],
[b].[state] AS [RCVBNKSTPRO],
[b].[zip] AS [RCVBNKPSTCD],
[cf].[contract_id] AS [contractId],
[s].[stateCode] AS [stateCode],
[cf].[id] AS [Id] FROM [dbo].[contractFunding] AS [cf] WITH (TABLOCKX, HOLDLOCK) 
	INNER JOIN [merchantOperatingAccounts] [moa] ON [cf].[merchantOperatingAccount_id] = [moa].[id] 
	INNER JOIN [dbo].[banks] [b] ON [moa].[bank_id] = [b].[id] 
	INNER JOIN [dbo].[state] [s] ON [b].[state_id] = [s].[id] 
	INNER JOIN [dbo].[merchants] [m] ON [cf].[merchant_id] = [m].[id] WHERE [cf].[transferStatus_id] = 2
		and [cf].[transferMethod_id] = 0

UPDATE [ameex_SFSDB].[dbo].[contractFunding] SET transferStatus_id = 2 where transferMethod_id= 0