SELECT 
spd.id, 
spd.contact_id, 
spd.accountNumber, 
-(spd.balanceNegativeDisbursement) as amount,  
spd.transferMethod_id,
ct.contactFirstName, 
ct.contactName, 
ct.legalName, 
bn.id as bank_id, 
bn.name AS bank_name, 
bn.routingNumber, 
bn.active, 
bn.is_ACH 
	FROM [dbo].[syndicatePartnerData] AS [spd] 
	INNER JOIN [dbo].[contacts] [ct] ON [spd].[contact_id] = [ct].[id] 
	LEFT JOIN [dbo].[banks] [bn] ON [spd].[bank_id] = [bn].[id] 
		WHERE spd.balanceNegativeDisbursement <> 0 AND spd.participationType_id <> 1

UPDATE syndicatePartnerData SET balanceNegativeDisbursement = '-150' WHERE id = '62'
UPDATE syndicatePartnerData SET balanceNegativeDisbursement = '-200' WHERE id = '771'