SELECT id, contract_id as contractId, merchant_id, clawback_amount AS amount, created_date FROM ameex_platform.commission_clawback_eligibility 
	WHERE approval = 1 and CONCAT(YEAR(created_date),MONTH(created_date)) = CONCAT(YEAR(now()),MONTH(now()));

UPDATE ameex_platform.commission_clawback_eligibility 
	SET created_date = now() 
	WHERE id IN (2,3,4,5,6,7) 
		and approval = 1 
		and year(created_date) <> year(now()) 
		and month(created_date) <> month(now());