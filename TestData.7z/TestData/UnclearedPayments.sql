UPDATE contractPaymentHistory SET date_cleared = null WHERE id = '100461621'
UPDATE syndicatePartnerData SET bank_id = 21 WHERE contact_id in (1797842);
UPDATE [ameex_SFSDB].[dbo].[contractFunding] SET [releaseddatestamp] = CURRENT_TIMESTAMP + 1
	WHERE [id] in (SELECT [id] FROM [ameex_SFSDB].[dbo].[contractFunding] WHERE id = 369831);

SELECT 
[cph].id as contractPaymentHistory_id, 
[cph].contract_id, 
[cph].amount, 
[st].amountAppliedToRTR, 
[st].contact_id, 
[c].merchant_id, 
[c].balanceCleared, 
[pph].id AS pph_id 
	FROM [dbo].[contractPaymentHistory] AS [cph] 
	LEFT OUTER JOIN [dbo].[syndicateTransactions] [st] ON [cph].[syndicateReference_id] = [st].[contractPaymentHistory_id] 
	LEFT OUTER JOIN [dbo].[contracts] [c] ON [c].[id] = [cph].[contract_id] 
	LEFT OUTER JOIN [dbo].[pendingPaymentHistory] [pph] ON [pph].[pendingPaymentReference_id ] = [cph].[pendingPaymentReference_id] 
		WHERE [cph].id in (100461621) AND [cph].date_cleared IS NULL;