SELECT 
ctr.id AS contractId, 
ct.contactFirstName, 
ct.contactName, 
ct.legalName, 
sp.contact_id, 
sp.account_number as accountNumber, 
bn.routingNumber, 
bn.active, bn.is_ACH 
	FROM [dbo].[contracts] AS [ctr] 
	INNER JOIN [dbo].[contacts] [ct] ON [ctr].[salesRep_id] = [ct].[id] 
	INNER JOIN [dbo].[salesPartnerPersonalData] [sp] ON [sp].[contact_id] = [ct].[id] 
	INNER JOIN [dbo].[banks] [bn] ON [sp].[bank_id] = [bn].[id] 
		WHERE [ctr].[id] IN (1947171,1366741,1378492,1662031,1762811,2214401);