import java.util.ArrayList;

public class NetflixShows {

	public static void main(String[] args) {
		
		String[] shows = new String[10];
		
		shows[0] = "Friends";
		shows[1] = "Everybody Hates Chris";
		shows[2] = "Drake and Josh";
		shows[3] = "Game Of Thrones";
		shows[4] = "The Walking Dead";
		shows[5] = "The Good Place";
		shows[6] = "Breaking Bad";
		shows[7] = "Orange is the New Black";
		shows[8] = "The Twilight Zone";
		shows[9] = "Parks and Recreation";
		
		for(int i = 0; i < shows.length; i++) {
			System.out.println(shows[i]);
		}
		
	}

}
