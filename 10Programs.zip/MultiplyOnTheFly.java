
public class MultiplyOnTheFly {

	public static void main(String[] args) {
		
		int m = multiply(48, 7);
		System.out.println(m);
		
	}
	
	public static int multiply(int a, int b) {
		return a * b;
	}

}
