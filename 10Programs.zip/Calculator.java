
public class Calculator {

	public static void main(String[] args) {
		
		int a = 4;
		int b = 2;
		
		System.out.println("Addition: " + (a + b));
		System.out.println("Subtraction: " + (a - b));
		System.out.println("Multiply: " + (a * b));
		System.out.println("Divide: " + (a / b));
		System.out.println("Remainder (mod): " + (a % b));
		System.out.println("Exponent: " + Math.pow(a, b));

		
		
	}
	
}
